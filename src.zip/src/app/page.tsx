import dynamic from 'next/dynamic';
import AboutSection from '@/components/about/AboutSection';
import Timeline from '@/components/timeline/Timeline';

const HeroScene = dynamic(() => import('@/components/hero/HeroScene'), {
  ssr: false,
  loading: () => (
    <div style={{
      width:'100vw', height:'100vh', background:'#000010',
      display:'flex', alignItems:'center', justifyContent:'center'
    }}>
      <div style={{
        width:3, height:3, borderRadius:'50%', background:'#7A3CFF',
        boxShadow:'0 0 60px 30px rgba(122,60,255,0.5)',
      }}/>
    </div>
  ),
});

export default function Home() {
  return (
    <main>
      <HeroScene />
      <div className="hero-spacer" aria-hidden="true" />

      <div id="post-hero">
        <div className="void-transition">
          <div className="void-transition-text">You made it through.</div>
          <div className="void-transition-sub">This is what remains.</div>
        </div>

        <AboutSection />
        <Timeline />
      </div>
    </main>
  );
}
