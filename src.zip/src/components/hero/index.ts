export { default } from './HeroScene';
