export { default } from './HeroScene';
