'use client';

import { useMemo, useRef } from 'react';
import type { MutableRefObject } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

type LayerConfig = {
  count: number;
  radiusMin: number;
  radiusMax: number;
  sizeMin: number;
  sizeMax: number;
  speed: number;
  opacity: number;
};

function createStarGeometry(config: LayerConfig) {
  const { count, radiusMin, radiusMax, sizeMin, sizeMax, speed } = config;
  const positions = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const seeds = new Float32Array(count);
  const velocities = new Float32Array(count * 3);
  const brightness = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    const u = Math.random();
    const v = Math.random();
    const theta = 2 * Math.PI * u;
    const phi = Math.acos(2 * v - 1);
    const r = THREE.MathUtils.randFloat(radiusMin, radiusMax);

    const sinPhi = Math.sin(phi);
    const x = r * sinPhi * Math.cos(theta);
    const y = r * Math.cos(phi);
    const z = r * sinPhi * Math.sin(theta);

    positions[i * 3] = x;
    positions[i * 3 + 1] = y;
    positions[i * 3 + 2] = z;

    sizes[i] = THREE.MathUtils.randFloat(sizeMin, sizeMax);
    seeds[i] = Math.random();
    brightness[i] = THREE.MathUtils.randFloat(0.5, 1.0);

    // very subtle drift
    const vel = speed * THREE.MathUtils.randFloat(0.2, 1.0);
    velocities[i * 3] = (Math.random() - 0.5) * vel;
    velocities[i * 3 + 1] = (Math.random() - 0.5) * vel;
    velocities[i * 3 + 2] = (Math.random() - 0.5) * vel;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));
  geometry.setAttribute('aVelocity', new THREE.BufferAttribute(velocities, 3));
  geometry.setAttribute('aBrightness', new THREE.BufferAttribute(brightness, 1));

  return geometry;
}

function StarLayer({ config, globalOpacity, scrollRef }: { config: LayerConfig; globalOpacity: number; scrollRef: MutableRefObject<number>; }) {
  const mat = useRef<THREE.ShaderMaterial>(null!);
  const geo = useMemo(() => createStarGeometry(config), [config]);

  useFrame(({ clock }) => {
    if (!mat.current) return;
    mat.current.uniforms.uTime.value = clock.getElapsedTime();
    mat.current.uniforms.uOpacity.value = globalOpacity * config.opacity;
    mat.current.uniforms.uScroll.value = scrollRef.current;
  });

  const material = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uOpacity: { value: 1 },
        uScroll: { value: 0 },
      },
      vertexShader: `
        attribute float aSize;
        attribute float aSeed;
        attribute vec3 aVelocity;
        attribute float aBrightness;

        uniform float uTime;
        uniform float uOpacity;
        uniform float uScroll;

        varying float vAlpha;
        varying float vBrightness;
        varying float vSeed;

        void main() {
          vec3 pos = position + aVelocity * uTime;
          pos.z += uScroll * 6.0 * (0.3 + aSeed);

          vec4 mv = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mv;

          float size = aSize * (200.0 / -mv.z);
          size = clamp(size, 0.0, 6.0);
          gl_PointSize = size;

          vAlpha = uOpacity;
          vBrightness = aBrightness;
          vSeed = aSeed;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        varying float vAlpha;
        varying float vBrightness;
        varying float vSeed;

        void main() {
          vec2 uv = gl_PointCoord - 0.5;
          float d = length(uv);

          float core = smoothstep(0.06, 0.0, d);
          float glow = smoothstep(0.48, 0.0, d);

          float twinkle = 0.7 + 0.3 * sin(uTime * 0.8 + vSeed * 12.0);
          float intensity = (core * 1.2 + glow * 0.45) * vBrightness * twinkle;

          vec3 cold = vec3(0.72, 0.82, 1.0);
          vec3 warm = vec3(1.0, 0.88, 0.7);
          vec3 color = mix(cold, warm, vBrightness * 0.2);

          gl_FragColor = vec4(color, intensity * vAlpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
  }, []);

  return (
    <points frustumCulled={false}>
      <primitive object={geo} />
      <primitive object={material} ref={mat} attach="material" />
    </points>
  );
}

export default function Starfield({ opacity, scrollRef }: { opacity: number; scrollRef: MutableRefObject<number>; }) {
  const layers: LayerConfig[] = useMemo(
    () => [
      { count: 900, radiusMin: 120, radiusMax: 240, sizeMin: 0.3, sizeMax: 0.9, speed: 0.0, opacity: 0.6 },
      { count: 420, radiusMin: 60, radiusMax: 120, sizeMin: 0.5, sizeMax: 1.4, speed: 0.003, opacity: 0.8 },
      { count: 160, radiusMin: 25, radiusMax: 60, sizeMin: 0.9, sizeMax: 2.0, speed: 0.01, opacity: 1.0 },
    ],
    []
  );

  return (
    <group>
      {layers.map((layer, i) => (
        <StarLayer key={i} config={layer} globalOpacity={opacity} scrollRef={scrollRef} />
      ))}
    </group>
  );
}
