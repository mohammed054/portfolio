'use client';

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export default function SpaceBackdrop({ opacity }: { opacity: number }) {
  const mat = useRef<THREE.ShaderMaterial>(null!);

  const material = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        uOpacity: { value: opacity },
      },
      vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uOpacity;
        varying vec3 vPos;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }

        void main() {
          float h = vPos.y * 0.5 + 0.5;
          vec3 top = vec3(0.02, 0.03, 0.08);
          vec3 bottom = vec3(0.0, 0.0, 0.02);
          vec3 base = mix(bottom, top, h);

          float n = hash(vPos.xy * 120.0 + vec2(12.3, 78.1));
          float dust = smoothstep(0.6, 1.0, n) * 0.05;

          vec3 nebula = vec3(0.04, 0.015, 0.08);
          base += nebula * dust;

          float vignette = smoothstep(0.0, 0.6, abs(vPos.x)) * 0.08;
          base -= vignette;

          gl_FragColor = vec4(base, uOpacity);
        }
      `,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false,
    });
  }, []);

  useFrame(({ clock }) => {
    if (!mat.current) return;
    mat.current.uniforms.uOpacity.value = opacity;
  });

  return (
    <mesh>
      <sphereGeometry args={[220, 32, 32]} />
      <primitive object={material} ref={mat} attach="material" />
    </mesh>
  );
}
