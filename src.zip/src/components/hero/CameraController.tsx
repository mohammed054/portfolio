'use client';

import { useFrame, useThree } from '@react-three/fiber';
import { MutableRefObject, useRef } from 'react';
import * as THREE from 'three';

export default function CameraController({
  scrollProgress
}: {
  scrollProgress: MutableRefObject<number>;
}) {
  const { camera } = useThree();

  const pos = useRef(new THREE.Vector3(0, 7.2, 28));
  const target = useRef(new THREE.Vector3());
  const look = useRef(new THREE.Vector3(0, 0, 0));

  useFrame(() => {
    const t = scrollProgress.current;

    const approach = THREE.MathUtils.smoothstep(t, 0.0, 0.58);
    const horizon = THREE.MathUtils.smoothstep(t, 0.42, 0.68);
    const dive = THREE.MathUtils.smootherstep(t, 0.68, 1.0);

    // Subtle orbit + wobble
    const orbit = Math.sin(t * 2.1) * (0.8 + horizon * 0.8);

    // Point of no return jitter
    const shockIn = THREE.MathUtils.smoothstep(t, 0.42, 0.52);
    const shockOut = THREE.MathUtils.smoothstep(t, 0.62, 0.72);
    const shock = Math.max(0, shockIn - shockOut);

    const baseY = THREE.MathUtils.lerp(7.2, -1.0, approach) - dive * 2.6;
    const baseZ = THREE.MathUtils.lerp(28, 6.0, approach) + THREE.MathUtils.lerp(0, -18, dive);

    target.current.set(
      orbit + Math.sin(t * 36) * 0.25 * shock,
      baseY + Math.cos(t * 28) * 0.2 * shock,
      baseZ + Math.sin(t * 22) * 0.15 * shock
    );

    // smooth movement
    pos.current.lerp(target.current, 0.08);

    const focus = THREE.MathUtils.smootherstep(t, 0.78, 0.9);

    // Look down at the disk, then pull into the void
    const lookTarget = new THREE.Vector3(
      Math.sin(t * 1.4) * 0.2,
      THREE.MathUtils.lerp(0.6, -1.4, approach) - dive * 1.2,
      THREE.MathUtils.lerp(0, -6, dive)
    );

    // Recenter on MH during reveal
    const mhTarget = new THREE.Vector3(0, -0.05, -3.8);
    look.current.lerpVectors(lookTarget, mhTarget, focus);

    camera.position.copy(pos.current);
    camera.lookAt(look.current);

    // subtle roll as we dive
    camera.rotation.z = Math.sin(t * 2.2) * 0.005 + dive * 0.06;
  });

  return null;
}
