'use client';

import BlackHoleLensing from './BlackHoleLensing';
import { useRef, useState, useEffect, useCallback, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import {
  EffectComposer,
  Bloom,
  ChromaticAberration,
  Vignette,
} from '@react-three/postprocessing';

import * as THREE from 'three';

import BlackHole from './BlackHoleModel';
import ParticleField from './ParticleField';
import MHInitials from './MHInitials';
import CameraController from './CameraController';
import { useMouse } from '@/hooks/useMouse';
import Starfield from './Starfield';
import SpaceBackdrop from './SpaceBackdrop';

type ScenePhase =
  | 'IDLE'
  | 'APPROACH'
  | 'HORIZON'
  | 'INSIDE'
  | 'MH_READY'
  | 'REVEALED'
  | 'RELEASED';

export default function HeroScene() {
  const scroll = useRef(0);
  const targetScroll = useRef(0);
  const velocity = useRef(0);

  const mouse = useMouse();

  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<ScenePhase>('IDLE');
  const [noReturn, setNoReturn] = useState(false);
  const noReturnRef = useRef(false);
  const NO_RETURN_AT = 0.46;

  const gravityRef = useRef(0);
  const lensingRef = useRef(0);

  // ─────────────────────────────
  // 🎯 PHASE SYSTEM
  // ─────────────────────────────
  useEffect(() => {
    if (progress > 0.03 && phase === 'IDLE') setPhase('APPROACH');
    if (progress > 0.5 && phase === 'APPROACH') setPhase('HORIZON');
    if (progress > 0.68 && phase === 'HORIZON') setPhase('INSIDE');
    if (progress > 0.82 && phase === 'INSIDE') setPhase('MH_READY');
  }, [progress, phase]);

  const showMH = phase === 'MH_READY' || phase === 'REVEALED' || phase === 'RELEASED';
  const revealed = phase === 'REVEALED' || phase === 'RELEASED';
  const released = phase === 'RELEASED';

  // ─────────────────────────────
  // 🌀 SCROLL ENGINE
  // ─────────────────────────────
  useEffect(() => {
    if (released) return;

    const SPEED = 0.0012;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();

      targetScroll.current += e.deltaY * SPEED;
      targetScroll.current = THREE.MathUtils.clamp(targetScroll.current, 0, 1);

      if (noReturnRef.current) {
        targetScroll.current = Math.max(targetScroll.current, NO_RETURN_AT);
      }

      // lock before reveal
      if (phase !== 'REVEALED') {
        targetScroll.current = Math.min(targetScroll.current, 0.95);
      }
    };

    window.addEventListener('wheel', onWheel, { passive: false });
    return () => window.removeEventListener('wheel', onWheel);
  }, [phase, released]);

  useEffect(() => {
    let raf: number;

    const update = () => {
      const diff = targetScroll.current - scroll.current;

      velocity.current = diff * 60;
      scroll.current += diff * 0.08;

      if (!noReturnRef.current && scroll.current > NO_RETURN_AT) {
        noReturnRef.current = true;
        setNoReturn(true);
      }

      const baseGravity =
        scroll.current * 1.2 + Math.abs(velocity.current) * 0.6;
      const noReturnBoost = Math.max(0, (scroll.current - NO_RETURN_AT) * 2.0);
      const gravityTarget = Math.min(1, baseGravity + noReturnBoost);
      gravityRef.current += (gravityTarget - gravityRef.current) * 0.08;

      const insideBlend = THREE.MathUtils.smootherstep(
        scroll.current,
        0.68,
        0.86
      );
      const lensTarget = gravityRef.current * (1 - insideBlend);
      lensingRef.current += (lensTarget - lensingRef.current) * 0.1;

      setProgress(scroll.current);
      raf = requestAnimationFrame(update);
    };

    raf = requestAnimationFrame(update);
    return () => cancelAnimationFrame(raf);
  }, []);

  // ─────────────────────────────
  // 🌌 GLOBAL GRAVITY SYSTEM (KEY)
  // ─────────────────────────────
  const gravity = gravityRef.current;
  const insideMix = THREE.MathUtils.smootherstep(progress, 0.68, 0.86);
  const outsideMix = 1 - insideMix;
  const mhFocus = THREE.MathUtils.smootherstep(progress, 0.78, 0.9);

  // ─────────────────────────────
  // 🎯 ACTIONS
  // ─────────────────────────────
  const handleMHClick = useCallback(() => {
    if (phase === 'MH_READY') setPhase('REVEALED');
  }, [phase]);

  // release scroll after reveal
  useEffect(() => {
    if (!revealed || released) return;

    const onWheel = (e: WheelEvent) => {
      if (e.deltaY > 0) {
        e.preventDefault();
        setPhase('RELEASED');

        setTimeout(() => {
          document.body.style.overflow = 'auto';
        }, 1200);
      }
    };

    window.addEventListener('wheel', onWheel, { passive: false });
    return () => window.removeEventListener('wheel', onWheel);
  }, [revealed, released]);

  // ─────────────────────────────
  // 🎬 CINEMATIC FX (NOW SYNCED)
  // ─────────────────────────────
  const bloomBase = 0.45 + gravity * 0.9;
  const bloom = THREE.MathUtils.lerp(bloomBase, 0.35, mhFocus) * (1 - insideMix * 0.4);
  const chromatic = 0.00018 + gravity * 0.006;
  const chromaOffset = useMemo(() => new THREE.Vector2(), []);
  chromaOffset.set(chromatic * outsideMix, chromatic * outsideMix);

  const textVisible = revealed;

  // ─────────────────────────────
  // 🎬 RENDER
  // ─────────────────────────────
  return (
    <div
      className={`hero-fixed ${released ? 'dive-out' : ''}`}
      style={{
        position: 'fixed',
        inset: 0,
        background: '#000',
        overflow: 'hidden',
        zIndex: 10,
      }}
    >
      <Canvas
        camera={{ position: [0, 7.2, 28], fov: 60 }}
        dpr={[1, 2]}
        gl={{
          antialias: true,
          powerPreference: 'high-performance',
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1,
        }}
      >
        <ambientLight intensity={0.02} />

        {/* CORE SYSTEM */}
        <CameraController scrollProgress={scroll} />

        <SpaceBackdrop opacity={0.9 * outsideMix + 0.2} />

        <Starfield opacity={outsideMix * (1 - mhFocus * 0.6)} scrollRef={scroll} />

        <ParticleField
          mouseRef={mouse}
          scrollProgress={scroll}
          scrollVelocity={velocity}
          count={900}
          insideMix={insideMix}
          opacity={(outsideMix + insideMix * 0.9) * (1 - mhFocus * 0.6)}
        />

        <BlackHole opacity={outsideMix} />

        {/* MH */}
        {showMH && (
          <MHInitials
            visible
            revealed={revealed}
            onClick={handleMHClick}
            mouseRef={mouse}
          />
        )}

        {/* POST */}
        <EffectComposer>
          {/* 🔥 LENSING — must live inside EffectComposer so it's collected via context */}
          <BlackHoleLensing strengthRef={lensingRef} />

          <Bloom
            intensity={bloom}
            luminanceThreshold={0.75}
            luminanceSmoothing={0.15}
          />

          <ChromaticAberration
            offset={chromaOffset}
          />

          <Vignette eskil={false} offset={0.18} darkness={0.85} />
        </EffectComposer>
      </Canvas>

      <div className="interstellar-glow" style={{ opacity: outsideMix }} />

      {/* UI */}
      <div className={`hero-text-overlay ${textVisible ? 'visible' : ''}`}>
        <h1 className="hero-name">
          Mohammed<br />Hassoun
        </h1>

        <p className="hero-role">Software Engineer</p>

        <p className="hero-tagline">
          "I only design what's necessary,<br />not what's flashy."
        </p>

        <div className="hero-cta">
          <button className="cta-btn cta-btn-primary">Explore Work</button>
          <button className="cta-btn cta-btn-secondary">Contact</button>
        </div>
      </div>

      {/* STATES */}
      {phase === 'IDLE' && (
        <div className="scroll-hint visible">
          <div className="sh-line" />
          <span className="sh-text">scroll to enter</span>
        </div>
      )}

      {phase === 'MH_READY' && (
        <div className="click-prompt visible">— click to reveal —</div>
      )}

      {revealed && !released && (
        <div className="dive-hint">
          <div className="dh-line" />
          <div className="dh-text">scroll to dive</div>
        </div>
      )}

      {(phase === 'APPROACH' || phase === 'HORIZON') && (
        <div className="void-label">
          {noReturn
            ? 'POINT OF NO RETURN'
            : progress < 0.5
            ? 'APPROACHING SINGULARITY'
            : progress < 0.68
            ? 'EVENT HORIZON'
            : 'SPAGHETTIFICATION'}
        </div>
      )}

    </div>
  );
}
