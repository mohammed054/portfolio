'use client';
/**
 * TimelineSection — "Gravity Path"
 *
 * Concept: Events caught in the gravitational pull of the singularity.
 * A curved SVG orbit path with nodes — each milestone a point of light
 * pulled toward the center.
 *
 * Scroll mechanic:
 *   • Outer wrapper is tall (N × 100vh + 2vh buffer)
 *   • Inner is position:sticky, 100vh — scroll drives the path progress
 *   • Progress 0→1 maps to active node index
 *   • NO page-style vertical list — this is scroll-within-canvas
 *
 * Visual layers:
 *   0. Background: deep black + subtle inward drifting particles (CSS)
 *   1. SVG path: glowing curved orbit, fills as nodes activate
 *   2. Nodes: dim dots → active: expand + light pulse
 *   3. Holographic text: no card, no background, just pure glowing type
 */
import { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { timeline } from '@/lib/data';

// ─── PATH MATH ───────────────────────────────────────────────────────────────
// Cubic bezier: P = (1-t)³P0 + 3(1-t)²tP1 + 3(1-t)t²P2 + t³P3
// We use a smooth S-curve across the viewport width.
// Viewport coords are normalised: x ∈ [0,1], y ∈ [0,1]

interface Vec2 { x: number; y: number; }
function cubicBez(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, t: number): Vec2 {
  const u = 1 - t;
  return {
    x: u*u*u*p0.x + 3*u*u*t*p1.x + 3*u*t*t*p2.x + t*t*t*p3.x,
    y: u*u*u*p0.y + 3*u*u*t*p1.y + 3*u*t*t*p2.y + t*t*t*p3.y,
  };
}

// The orbital path: a broad S-curve from left→right with vertical undulation
// These are normalised [0,1] coords; we scale to SVG viewBox 1000×500
const P0: Vec2 = { x: 0.04, y: 0.50 };
const P1: Vec2 = { x: 0.22, y: 0.12 };
const P2: Vec2 = { x: 0.78, y: 0.88 };
const P3: Vec2 = { x: 0.96, y: 0.50 };

// t values where each node sits along the curve (evenly spread, not at ends)
const N = timeline.length;
const NODE_T = Array.from({ length: N }, (_, i) => 0.09 + (i / (N - 1)) * 0.82);

function getNodePos(t: number, W: number, H: number): Vec2 {
  const n = cubicBez(P0, P1, P2, P3, t);
  return { x: n.x * W, y: n.y * H };
}

// Build the full SVG path `d` string from 200 interpolated points
function buildPathD(W: number, H: number): string {
  const pts = Array.from({ length: 200 }, (_, i) => {
    const p = cubicBez(P0, P1, P2, P3, i / 199);
    return `${p.x * W},${p.y * H}`;
  });
  return `M ${pts.join(' L ')}`;
}

// ─── MAIN COMPONENT ──────────────────────────────────────────────────────────
export default function TimelineSection() {
  const outerRef  = useRef<HTMLDivElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const pathRef   = useRef<SVGPathElement>(null);

  const [progress,     setProgress]     = useState(0); // 0→1 scroll through section
  const [activeIndex,  setActiveIndex]  = useState(-1);
  const [dim,          setDim]          = useState({ W: 1000, H: 480 });
  const [sectionVis,   setSectionVis]   = useState(false);

  // Responsive path dimensions
  useEffect(() => {
    const upd = () => {
      const w = Math.min(window.innerWidth, 1400);
      setDim({ W: w, H: Math.round(w * 0.44) });
    };
    upd();
    window.addEventListener('resize', upd);
    return () => window.removeEventListener('resize', upd);
  }, []);

  // Intersection trigger for section visibility
  useEffect(() => {
    const el = outerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) setSectionVis(true);
    }, { threshold: 0.05 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Scroll driver — maps scroll position within section to 0→1 progress
  useEffect(() => {
    const onScroll = () => {
      const outer = outerRef.current;
      if (!outer) return;
      const rect = outer.getBoundingClientRect();
      const totalScroll = outer.offsetHeight - window.innerHeight;
      const scrolled    = -rect.top;
      const p = Math.max(0, Math.min(1, scrolled / totalScroll));
      setProgress(p);

      // Map progress to active node — spread evenly across 0→1
      const idx = Math.floor(p * N);
      setActiveIndex(Math.min(idx, N - 1));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Memoised per-dimension computations
  const pathD     = useMemo(() => buildPathD(dim.W, dim.H), [dim]);
  const nodePositions = useMemo(() =>
    NODE_T.map(t => getNodePos(t, dim.W, dim.H)),
  [dim]);

  // Text placement: alternate top/bottom based on y position
  const nodeSide = useCallback((i: number): 'top' | 'bottom' => {
    const pos = nodePositions[i];
    return pos.y < dim.H * 0.5 ? 'bottom' : 'top';
  }, [nodePositions, dim]);

  // How far along path fill should go (up to activeIndex node)
  const fillProgress = activeIndex >= 0
    ? NODE_T[Math.min(activeIndex, N - 1)]
    : 0;

  return (
    <div
      ref={outerRef}
      id="timeline"
      className="tl2-outer"
      /* Height = N sections + 1.5 buffer so first and last node get full screen time */
      style={{ height: `${(N + 1.5) * 100}vh` }}
    >
      <div ref={stickyRef} className="tl2-sticky">

        {/* Background particles */}
        <div className="tl2-bg" aria-hidden>
          {Array.from({ length: 30 }).map((_, i) => (
            <span key={i} className="tl2-drift" style={{
              left:  `${(i * 37 + 5) % 98}%`,
              top:   `${(i * 61 + 9) % 96}%`,
              animationDelay:    `${(i * 0.5) % 8}s`,
              animationDuration: `${12 + (i * 1.1) % 16}s`,
              width: `${1 + (i % 2)}px`, height: `${1 + (i % 2)}px`,
            }} />
          ))}
        </div>

        {/* ── HEADER ────────────────────────────────────────── */}
        <div className={`tl2-header${sectionVis ? ' tl2-header-in' : ''}`}>
          <span className="tl2-header-label">— Gravity Path</span>
          <p className="tl2-header-count">
            {activeIndex >= 0 ? activeIndex + 1 : 0} / {N}
          </p>
        </div>

        {/* ── SVG PATH + NODES ──────────────────────────────── */}
        <div
          className={`tl2-path-wrap${sectionVis ? ' tl2-path-in' : ''}`}
          style={{ width: dim.W, height: dim.H }}
        >
          <svg
            viewBox={`0 0 ${dim.W} ${dim.H}`}
            width={dim.W}
            height={dim.H}
            fill="none"
            style={{ overflow: 'visible', display: 'block' }}
          >
            <defs>
              {/* Glow filter for path */}
              <filter id="pathGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              {/* Glow for active node */}
              <filter id="nodeGlow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="8" result="blur" />
                <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              {/* Clip to fill progress */}
              <clipPath id="pathFill">
                <rect
                  x="0" y="0"
                  width={fillProgress * dim.W * 1.05}
                  height={dim.H}
                  style={{ transition: 'width 0.5s ease' }}
                />
              </clipPath>
            </defs>

            {/* Base dim path */}
            <path
              d={pathD}
              stroke="rgba(255,255,255,0.06)"
              strokeWidth="1.5"
              strokeLinecap="round"
            />

            {/* Illuminated fill (progress-clipped) */}
            <path
              ref={pathRef}
              d={pathD}
              stroke="rgba(0,200,255,0.55)"
              strokeWidth="1.5"
              strokeLinecap="round"
              filter="url(#pathGlow)"
              clipPath="url(#pathFill)"
              style={{ transition: 'opacity 0.5s ease' }}
            />
            {/* Bright core of fill */}
            <path
              d={pathD}
              stroke="rgba(180,240,255,0.22)"
              strokeWidth="0.6"
              clipPath="url(#pathFill)"
            />

            {/* ── NODES ────────────────────────────────────── */}
            {nodePositions.map((pos, i) => {
              const isActive = i === activeIndex;
              const isPast   = i < activeIndex;
              const opacity  = isPast ? 0.4 : isActive ? 1 : 0.15;
              const r        = isActive ? 8 : isPast ? 5 : 4;

              return (
                <g key={i} style={{ transition: 'opacity 0.5s ease', opacity }}>
                  {/* Pulse ring for active */}
                  {isActive && (
                    <>
                      <circle cx={pos.x} cy={pos.y} r={16} fill="none"
                        stroke="rgba(0,200,255,0.35)"
                        strokeWidth="1"
                        className="tl2-pulse-ring" />
                      <circle cx={pos.x} cy={pos.y} r={26} fill="none"
                        stroke="rgba(0,200,255,0.15)"
                        strokeWidth="0.8"
                        className="tl2-pulse-ring-2" />
                    </>
                  )}

                  {/* Node dot */}
                  <circle
                    cx={pos.x} cy={pos.y}
                    r={r}
                    fill={isActive ? '#00C8FF' : isPast ? 'rgba(0,160,220,0.6)' : 'rgba(80,120,180,0.4)'}
                    filter={isActive ? 'url(#nodeGlow)' : undefined}
                    style={{ transition: 'r 0.4s ease, fill 0.4s ease' }}
                  />

                  {/* Inner bright core */}
                  <circle
                    cx={pos.x} cy={pos.y} r={r * 0.4}
                    fill={isActive ? 'rgba(220,248,255,0.95)' : 'rgba(180,210,255,0.5)'}
                  />
                </g>
              );
            })}
          </svg>

          {/* ── NODE TEXT (holographic — NO card) ─────────── */}
          {nodePositions.map((pos, i) => {
            const isActive  = i === activeIndex;
            const isTop     = nodeSide(i) === 'top';
            const textW     = Math.min(300, dim.W * 0.22);
            // Clamp left so text stays inside viewport
            const left      = Math.max(8, Math.min(pos.x - textW / 2, dim.W - textW - 8));
            const topOffset = isTop ? pos.y - 14 : pos.y + 18;
            return (
              <div
                key={i}
                className={`tl2-node-text${isActive ? " tl2-node-text-active" : ""}`}
                style={{
                  position: "absolute",
                  left: left,
                  top: isTop ? undefined : topOffset,
                  bottom: isTop ? dim.H - topOffset : undefined,
                  width: textW,
                  textAlign: Math.abs(pos.x - dim.W / 2) < dim.W * 0.15 ? "center"
                           : pos.x < dim.W / 2 ? "left" : "right",
                  transform: isTop ? "translateY(-100%)" : "translateY(0)",
                }}
              >
                <span className="tl2-node-year-bg">{timeline[i].year}</span>
                <div className="tl2-node-content">
                  <span className="tl2-node-year-label">{timeline[i].year}</span>
                  <p className="tl2-node-title">{timeline[i].title}</p>
                  <p className="tl2-node-sub">{timeline[i].subtitle}</p>
                  <p className="tl2-node-desc">{timeline[i].description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* ── SCROLL PROGRESS INDICATOR ─────────────────────── */}
        <div className="tl2-progress-bar">
          <div className="tl2-progress-fill" style={{ width: `${progress * 100}%` }} />
        </div>

        {/* ── BOTTOM PROMPT ─────────────────────────────────── */}
        {activeIndex === N - 1 && (
          <div className="tl2-complete">
            <span>scroll to continue</span>
            <div className="tl2-complete-line" />
          </div>
        )}

      </div>
    </div>
  );
}