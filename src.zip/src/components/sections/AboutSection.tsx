'use client';
/**
 * AboutSection — "Core Identity Orb"
 *
 * Concept: You've gone through the singularity. The Orb is the compressed
 * identity that remains — information encoded in light.
 * Text decodes character by character, like being reconstructed from the sphere.
 *
 * Layers (back → front):
 *   0. Section bg: pure black + drifting ambient particles (CSS only)
 *   1. Orb: Canvas 2D — core glow + orbital particle planes + fresnel ring
 *   2. Text: character-scramble "decode" effect
 *   3. Stats: count-up numbers
 */
import { useRef, useEffect, useState, useCallback } from 'react';

// ─── CHARACTER SCRAMBLE ──────────────────────────────────────────────────────
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@$%';

function useScramble(target: string, active: boolean, delay = 0): string {
  const [display, setDisplay] = useState('');
  useEffect(() => {
    if (!active) return;
    const t = setTimeout(() => {
      let i = 0, iters = 0;
      const MAX = 3;
      const step = () => {
        if (i >= target.length) { setDisplay(target); return; }
        const done   = target.slice(0, i);
        const cur    = iters < MAX ? CHARS[Math.floor(Math.random() * CHARS.length)] : target[i];
        const rest   = target.slice(i + 1).replace(/\S/g, '·');
        setDisplay(done + cur + rest);
        iters++;
        if (iters > MAX) { iters = 0; i++; }
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }, delay);
    return () => clearTimeout(t);
  }, [active, target, delay]);
  return display;
}

// ─── ORB CANVAS ──────────────────────────────────────────────────────────────
function OrbCanvas({ size, active }: { size: number; active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouse     = useRef({ nx: 0, ny: 0 });
  const activeRef = useRef(false);
  activeRef.current = active;

  const onMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = canvasRef.current!.getBoundingClientRect();
    mouse.current = {
      nx: ((e.clientX - r.left) / r.width  - 0.5) * 2,
      ny: ((e.clientY - r.top ) / r.height - 0.5) * 2,
    };
  }, []);
  const onLeave = useCallback(() => { mouse.current = { nx: 0, ny: 0 }; }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx    = canvas.getContext('2d')!;
    const cx = size / 2, cy = size / 2;
    const R  = size * 0.29; // base orb radius

    // Build orbital particle planes
    type P = { a: number; r: number; tilt: number; speed: number; sz: number; b: number; hue: number; };
    const mkPlane = (n: number, rMin: number, rMax: number, tilt: number, spd: number): P[] =>
      Array.from({ length: n }, () => ({
        a:    Math.random() * Math.PI * 2,
        r:    rMin + Math.random() * (rMax - rMin),
        tilt, sz: 0.7 + Math.random() * 1.9,
        speed: (0.004 + Math.random() * 0.006) * spd * (Math.random() < 0.5 ? 1 : -1),
        b:    0.3 + Math.random() * 0.7,
        hue:  190 + Math.random() * 45,
      }));

    const planes = [
      mkPlane(40, R * 0.50, R * 0.96, Math.PI / 2,        1.00),
      mkPlane(28, R * 0.60, R * 0.88, Math.PI / 2 - 0.55, 0.72),
      mkPlane(22, R * 0.45, R * 0.78, Math.PI / 2 + 0.82, 0.55),
      mkPlane(14, R * 0.28, R * 0.58, Math.PI / 4,        0.88),
    ];

    let appear = 0, t = 0;
    let raf: number;

    const draw = () => {
      t += 0.012;
      if (activeRef.current) appear = Math.min(1, appear + 0.018);
      else                    appear = Math.max(0, appear - 0.02);

      ctx.clearRect(0, 0, size, size);
      if (appear < 0.005) { raf = requestAnimationFrame(draw); return; }

      const hov   = Math.hypot(mouse.current.nx, mouse.current.ny) > 0.1;
      const hBoost = hov ? 1.25 : 1.0;
      const scale  = appear * (0.93 + Math.sin(t * 0.75) * 0.010);

      ctx.save();
      ctx.translate(cx + mouse.current.nx * 5, cy + mouse.current.ny * 5);
      ctx.scale(scale, scale);

      // Outer ambient corona
      const cG = ctx.createRadialGradient(0, 0, R * 0.55, 0, 0, R * 1.45 * hBoost);
      cG.addColorStop(0,   `rgba(0,160,255,${0.045 * appear})`);
      cG.addColorStop(0.6, `rgba(0,90,200,${0.020 * appear})`);
      cG.addColorStop(1,   'rgba(0,0,0,0)');
      ctx.fillStyle = cG;
      ctx.beginPath(); ctx.arc(0, 0, R * 1.45 * hBoost, 0, Math.PI * 2); ctx.fill();

      // Orb body (dark glossy sphere)
      const bG = ctx.createRadialGradient(-R * 0.22, -R * 0.18, 0, 0, 0, R * hBoost);
      bG.addColorStop(0,   `rgba(18, 34, 64, ${0.94 * appear})`);
      bG.addColorStop(0.55,`rgba(7,  15, 30, ${0.90 * appear})`);
      bG.addColorStop(1,   `rgba(2,   6, 16, ${0.85 * appear})`);
      ctx.fillStyle = bG;
      ctx.beginPath(); ctx.arc(0, 0, R * hBoost, 0, Math.PI * 2); ctx.fill();

      // Inner core glow
      const iG = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.44);
      iG.addColorStop(0,   `rgba(160,230,255,${0.58 * appear * hBoost})`);
      iG.addColorStop(0.35,`rgba(60, 155,255,${0.28 * appear})`);
      iG.addColorStop(0.75,`rgba(20,  80,200,${0.10 * appear})`);
      iG.addColorStop(1,   'rgba(0,0,0,0)');
      ctx.fillStyle = iG;
      ctx.beginPath(); ctx.arc(0, 0, R * 0.44, 0, Math.PI * 2); ctx.fill();

      // Singularity point
      const sG = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.11);
      sG.addColorStop(0, `rgba(230,248,255,${0.98 * appear})`);
      sG.addColorStop(1, 'rgba(100,190,255,0)');
      ctx.fillStyle = sG;
      ctx.beginPath(); ctx.arc(0, 0, R * 0.11, 0, Math.PI * 2); ctx.fill();

      // Orbital particles — 3D projection
      const spdMul = hov ? 1.65 : 1.0;
      for (const plane of planes) {
        for (const p of plane) {
          p.a += p.speed * spdMul;
          const x3 = Math.cos(p.a) * p.r;
          const y3 = Math.sin(p.a) * p.r;
          const tiltY = p.tilt + mouse.current.ny * 0.28;
          const px = x3;
          const py = y3 * Math.sin(tiltY);
          const z  = y3 * Math.cos(tiltY);

          // skip if would be outside sphere
          if (Math.hypot(px, py) > R * hBoost * 0.98) continue;
          const depth = (z / p.r + 1) * 0.5; // 0(back)→1(front)
          const alpha = p.b * depth * appear * (hov ? 1.25 : 1);
          ctx.beginPath();
          ctx.arc(px, py, p.sz * (0.45 + depth * 0.8), 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${p.hue},88%,${68 + depth * 22}%,${alpha})`;
          ctx.fill();
        }
      }

      // Fresnel rim
      const rimA = (0.22 + Math.sin(t * 1.3) * 0.09) * appear * hBoost;
      ctx.beginPath(); ctx.arc(0, 0, R * hBoost * 0.994, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(0,210,255,${rimA})`; ctx.lineWidth = 1.3; ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, R * hBoost * 1.09, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(0,150,220,${rimA * 0.35})`; ctx.lineWidth = 0.7; ctx.stroke();

      // Specular highlight
      const hG = ctx.createRadialGradient(-R * 0.28, -R * 0.30, 0, -R * 0.26, -R * 0.28, R * 0.38);
      hG.addColorStop(0, `rgba(220,240,255,${0.08 * appear})`);
      hG.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = hG;
      ctx.beginPath(); ctx.arc(0, 0, R * hBoost, 0, Math.PI * 2); ctx.fill();

      ctx.restore();
      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [size]);

  return (
    <canvas ref={canvasRef} width={size} height={size}
      onMouseMove={onMove} onMouseLeave={onLeave}
      style={{ display: 'block', cursor: 'none' }} />
  );
}

// ─── COUNT-UP NUMBER ─────────────────────────────────────────────────────────
function CountUp({ to, suffix, active, delay }: { to: number; suffix: string; active: boolean; delay: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!active) return;
    const t = setTimeout(() => {
      let v = 0;
      const step = () => {
        v++;
        setN(Math.min(v, to));
        if (v < to) setTimeout(step, 24);
      };
      step();
    }, delay);
    return () => clearTimeout(t);
  }, [active, to, delay]);
  return <>{n}{suffix}</>;
}

// ─── SECTION ─────────────────────────────────────────────────────────────────
const LINES = [
  { t: "I don't build interfaces.",        d: 100  },
  { t: "I design controlled experiences.", d: 480  },
];
const PRINCIPLES = [
  { t: "Systems over features",     d: 900  },
  { t: "Precision over volume",     d: 1100 },
  { t: "Performance over noise",    d: 1300 },
];

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [active,  setActive]  = useState(false);
  const [orbSize, setOrbSize] = useState(360);

  const l0 = useScramble(LINES[0].t, active, LINES[0].d);
  const l1 = useScramble(LINES[1].t, active, LINES[1].d);
  const p0 = useScramble(PRINCIPLES[0].t, active, PRINCIPLES[0].d);
  const p1 = useScramble(PRINCIPLES[1].t, active, PRINCIPLES[1].d);
  const p2 = useScramble(PRINCIPLES[2].t, active, PRINCIPLES[2].d);

  useEffect(() => {
    const r = () => setOrbSize(window.innerWidth < 500 ? 220 : window.innerWidth < 900 ? 290 : 370);
    r();
    window.addEventListener('resize', r);
    return () => window.removeEventListener('resize', r);
  }, []);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setActive(true); }, { threshold: 0.22 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="about" className="about2-section">

      {/* Ambient drifting particles */}
      <div className="about2-bg" aria-hidden>
        {Array.from({ length: 24 }).map((_, i) => (
          <span key={i} className="about2-drift" style={{
            left: `${(i * 41 + 3) % 97}%`,
            top:  `${(i * 67 + 11) % 95}%`,
            animationDelay:    `${(i * 0.4) % 7}s`,
            animationDuration: `${10 + (i * 1.2) % 14}s`,
            width:  `${1 + (i % 3)}px`, height: `${1 + (i % 3)}px`,
          }} />
        ))}
      </div>

      <div className="about2-inner">

        {/* ── ORB ───────────────────────────────────────────── */}
        <div className="about2-orb-col">
          <p className={`about2-orb-label${active ? ' a2-in' : ''}`}
            style={{ '--td': '0s' } as React.CSSProperties}>
            CORE IDENTITY
          </p>
          <div className="about2-canvas-wrap" style={{ width: orbSize, height: orbSize }}>
            <OrbCanvas size={orbSize} active={active} />
            <div className="about2-orb-floor" style={{ width: orbSize * 0.65 }} />
          </div>
          {/* Stats */}
          <div className={`about2-stats${active ? ' a2-in' : ''}`}
            style={{ '--td': '1.5s' } as React.CSSProperties}>
            {[
              { to: 5,  s: '+', lbl: 'Years'    },
              { to: 40, s: '+', lbl: 'Projects' },
              { to: 12, s: '+', lbl: 'Clients'  },
            ].map(({ to, s, lbl }, i) => (
              <div key={i} className="about2-stat">
                <span className="about2-stat-n">
                  <CountUp to={to} suffix={s} active={active} delay={1500 + i * 180} />
                </span>
                <span className="about2-stat-l">{lbl}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── TEXT ──────────────────────────────────────────── */}
        <div className="about2-text-col">

          <p className={`about2-eyebrow${active ? ' a2-in' : ''}`}
            style={{ '--td': '0.05s' } as React.CSSProperties}>
            — Software Engineer
          </p>

          <div className="about2-statement">
            {[l0, l1].map((ln, i) => (
              <p key={i} className={`about2-line${active ? ' a2-in' : ''}`}
                style={{ '--td': `${0.1 + i * 0.12}s` } as React.CSSProperties}>
                {ln || '\u00a0'}
              </p>
            ))}
          </div>

          <div className={`about2-avail${active ? ' a2-in' : ''}`}
            style={{ '--td': '0.55s' } as React.CSSProperties}>
            <span className="avail-dot-green" />
            <span className="avail-label">Available for work</span>
          </div>

          <div className="about2-principles">
            {[p0, p1, p2].map((p, i) => (
              <div key={i} className={`about2-principle${active ? ' a2-in' : ''}`}
                style={{ '--td': `${0.75 + i * 0.18}s` } as React.CSSProperties}>
                <span className="apr-dash">—</span>
                <span className="apr-text">{p || '\u00a0'}</span>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}